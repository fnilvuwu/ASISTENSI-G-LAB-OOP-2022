public class SelfUtils {
    public static void displaySelf(){
        System.out.println("Nama : AL QADRI ");
        System.out.println("NIM : H071221052 ");


    }
    
}
